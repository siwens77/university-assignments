#undirected graph
class Graph:
    def __init__(self, adj_list):
        self.adj_list = adj_list
    
    def getDegree(self):
        max_l, vertex = 0, 0
        for i in self.adj_list:
            if len(self.adj_list[i]) > max_l:
                max_l = len(self.adj_list[i])
                vertex = i
        print("Highest degree is", max_l, "and it belongs to vertex", vertex)
        return max_l


adj_list = {
    1: [2, 3],
    2: [1, 3, 4],
    3: [1, 2],
    4: [2]
}
g = Graph(adj_list)
g.getDegree()
