#undirected graph
class Graph:
    def __init__(self, matrix):
        self.matrix = matrix
    
    def getnumE(self):
        length = len(self.matrix[0])
        print("there are", length, "edges")
        return length

# Example usage
matrix = [[1, 0], [0, 1], [0, 1], [1, 0]]
g = Graph(matrix)
g.getnumE()