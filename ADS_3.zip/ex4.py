#undirected
class Graph:
    def __init__(self, adj_list):
        self.adj_list = adj_list

    def DFS(self, start, visited= None):
        if visited == None:
            visited = set()
        visited.add(start)
        print(visited, end=" ")
        for i in self.adj_list[start]:
            if i not in visited:
                self.DFS(i, visited)
        return
    
    def BFS(self, start, visited=None, queue = None):
        if visited == None:
            visited = set()
        if queue == None:
            queue = [start]

        while queue:
            node = queue.pop(0)
            if node not in visited:
                visited.add(node)
                print(visited, end=" ")
                for i in self.adj_list[node]:
                    if (i not in visited) and (i not in queue):
                        queue.append(i)
        return
        

adj_list = {
    1: [2, 3],
    2: [1, 3, 4],
    3: [1, 2],
    4: [2]
}
m = Graph(adj_list)
print("Vertices visited using DFS:", end=" ")
m.DFS(1)
print("\nVertices visited using BFS:", end=" ")
m.BFS(1)