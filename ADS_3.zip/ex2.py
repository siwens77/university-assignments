#undirected graph
class Graph:
    def __init__(self, n, n_edge):
        self.n_edge = n_edge
        self.matrix = [[0 for _ in range(n_edge)] for _ in range(n)]
    
    def printMatrix(self):
        alphabet = 65 
        print(end="   ")
        for j in range(1, self.n_edge + 1):
            print(j, end=" ")
        print()
        for i in self.matrix:
            print(chr(alphabet), end="  ")
            for j in i:
                print(j, end=" ")
            print()
            alphabet += 1
    
    def getEdge(self, E):
        for i in E:
            self.matrix[i[0]][i[1]] = 1


## E is set of edges and first number in pair represent name of the edge and second vertex attached to it
## so in E = (x, y) -> "x" is a vertex with attached edge "y" to it  
## but if edges is attached to it IT MUST BE ALSO CONNECTED TO EXACTLY ONE ANOTHED VARTEX!!
## e.g if there exists x such that (x,3) there must be also exactly one y such that (y,3)


E = [(2, 1), (1, 1), (0, 0), (3, 0)]
g = Graph(4, 2)
g.getEdge(E)
g.printMatrix()
