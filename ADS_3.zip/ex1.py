#undirected graph
class Graph:
    def __init__(self, n):
        self.n = n
        self.matrix = [[0 for _ in range(n)] for _ in range(n)]

    def add_edge(self, u,v, matrix):
        self.matrix[u][v] = 1
        self.matrix[v][u] = 1
    def printMatrix(self):
        for i in self.matrix:
            for j in i:
                print(j, end=" ")
            print()
        return


m = Graph(3)
m.add_edge(1,2,m)
m.printMatrix()