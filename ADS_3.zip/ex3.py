#undirected graph
class Graph:
    def __init__(self, adj_list):
        self.adj_list = adj_list
    
    def conversion(self):
        keys = list(self.adj_list.keys())
        E = []
        for i in keys:
            for j in self.adj_list[i]:
                if [j, i] not in E:
                    E.append([i, j])
        return E


adj_list = {
    1: [2, 3],
    2: [1, 3, 4],
    3: [1, 2],
    4: [2]
}
g = Graph(adj_list)
print(g.conversion())