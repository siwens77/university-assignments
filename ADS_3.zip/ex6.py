def answer(matrix, a, b, adj_list):
        matrix[a][b] = 1 
        #take O(1) time complexity because we are changing value at given location
        adj_list[a].append(b) 
        #take also O(1) time because we are only adding to the list but takes O(n) if checking duplicate edges

#conclusion:
#there is no difference in time complexity(if we are not checking for duplicates)