#undirected graph
class Graph:
    def __init__(self, adj_list):
        self.adj_list = adj_list
    
    def FindPath(self, start, destination, queue=None, visited=None):
        if start == destination:
            print("Found! \nvisited nodes:", visited)
            return
        if queue == None:
            queue = [start]
        if visited == None:
            visited = set()
        visited.add(start)
        for i in self.adj_list[start]:
            if i not in visited and i not in queue:
                queue.append(i)
        queue = queue[1:]
        print(queue, visited)
        if len(queue)==0:
            print("NOT FOUND!")
            return 
        self.FindPath(queue[0], destination, queue, visited)
        
        

adj_list = {
    1: [2, 3],
    2: [1, 3, 4],
    3: [1, 2],
    4: [2]
}
m = Graph(adj_list)
m.FindPath(1,4)
