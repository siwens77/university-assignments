class Node:
    def __init__(self, value):
        self.value = value #value
        self.lChild = None #smaller
        self.rChild = None #bigger

def create_tree(value):
    new_node = Node(value)
    return new_node

def insert(value, root):
    if root == None:
        return create_tree(value)
    if root.value > value:
        root.lChild = insert(value, root.lChild)
    elif root.value < value:
        root.rChild = insert(value,root.rChild)
    return root

def getInfo(value, root):
    if root == None:
        print("VALUE OR ROOT NOT FOUND")
        return
    if value == root.value:
        print("FOUND! Value: ", root.value)
        if root.lChild:
            print("Left child: ", root.lChild.value)
        if root.rChild:
            print("Right child: ", root.rChild.value)
        return
    elif value > root.value:
        getInfo(value, root.rChild)
    elif value < root.value:
        getInfo(value, root.lChild)
    return

def printing(root):
    if root!=None:
        printing(root.lChild)
        print(root.value, end = " ")
        printing(root.rChild)

def minValue(node):
    current = node
    while (current.lChild != None):
        current = current.lChild
    return current

def delete(root, value):
    if root == None:
        return root
    if value<root.value:
        root.lChild = delete(root.lChild, value)
    elif value>root.value:
        root.rChild = delete(root.rChild, value)
    else:
        if root.lChild == None:
            temp = root.rChild
            root = None
            return temp
        elif root.rChild == None:
            temp = root.lChild
            root = None
            return temp

        temp = minValue(root, value)
        root.value = root.temp
        root.right = delete(root.right, temp.value)
    return root

def edit(NEW, value, r):
    delete(r, value)
    insert(NEW, r)
    return r

r = create_tree(8)          ##creating tree
r = insert(1,r)
r = insert(3,r)
r = insert(8,r)
r = insert(6,r)
r = insert(4,r)
r = insert(7,r)
r = insert(1555,r)
r = insert(14,r)            ##inserting node
getInfo(8,r)                ##searching for element
delete(r, 3)                ##deleting node with given value
edit(1111111, 1, r)         ##edit any node with new value and change the tree 
printing(r)                 ##printing whole tree