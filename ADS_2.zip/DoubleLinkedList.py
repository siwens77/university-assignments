class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.previous = None


class DoubleLinkedList:
    def __init__(self):
        self.head = None


    def InsertAtBeginning(self, data):
        if (self.head ==None):
            self.head = Node(data)
            return
        new_node = Node(data)
        self.head.previous = new_node
        new_node.next = self.head
        self.head = new_node


    def InsertAtIndex(self, data, index):
        if index == 0:
            self.InsertAtBeginning(self,data)
            return
        
        i = 0
        current_node = self.head
        while (i+1!=index and current_node!=None):
            i+=1
            current_node = current_node.next
        
        if current_node != None:
            A, B, C = current_node, Node(data), current_node.next
            B.previous = A
            B.next = C
            A.next = B
            C.previous = B
        else:
            print("error")


    def PrintingList(self):
        current_node = self.head
        while(current_node.next):
            print(current_node.data, end=" -> ")
            current_node = current_node.next
        print(current_node.data)


    def PrintingElement(self, index):
        current_node = self.head
        i = 0
        while (i!=index and current_node != None):
            current_node = current_node.next
            i +=1
        print("Your element at index", index, "is", current_node.data)
        if(current_node.previous and current_node.next):
            print("Previous element is", current_node.previous.data)
            print("Next element is", current_node.next.data)


    def DeletingIndex(self, index):
        print("Deleting item at index:", index)
        if index == 0:
            self.head.next.previous = None
            self.head = self.head.next
            print(llist.PrintingList())
            return

        current_node = self.head
        i = 0
        while (i+1!=index and current_node.next!=None):
            current_node = current_node.next
            i+=1
        
        A,C = current_node, current_node.next.next
        A.next = C
        C.previous = A


    def DeletingValue(self, value):
        if self.head.data == value:
            self.head.next.previous = None
            self.head = self.head.next
            print(llist.PrintingList(), "\n")
            print("You deleted", value, "value")
            return
        
        current_value = self.head
        while(current_value.next!=None and current_value.next.data!=value):
            current_value = current_value.next
        A,C = current_value, current_value.next.next
        A.next = C
        C.previous = A
        llist.PrintingList()
        print("You deleted", value, "value")

    def getInfo(self,value):
        current = self.head
        while (current.data != value and current.next):
            current = current.next
        if current.data ==value:
            print("value, next node, previous node: ", value, current.next.data, current.previous.data)
        else:
            print("value not found")

    def UpdateData(self,value, NEW):
        current = self.head
        while (current.data != value and current.next):
            current = current.next
        if current.data ==value:
            current.data = NEW
        else:
            print("value not found")

llist = DoubleLinkedList()
llist.InsertAtBeginning('A')
llist.InsertAtBeginning('B')        ##inserting at begginning
llist.InsertAtIndex('C', 1)
llist.InsertAtIndex('E', 1)
llist.InsertAtIndex('D', 2)         ##inserting at index
llist.PrintingElement(3)            ##printing info about node by index
llist.DeletingIndex(2)              ##deleting node by index
llist.DeletingValue('C')            ##deleting node by value
llist.getInfo('E')                  ##getting info about node
llist.UpdateData('E', 3)            ##updating data
llist.PrintingList()                ##printing list